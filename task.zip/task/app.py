import json
import requests
import os
from flask import Flask, render_template, request, jsonify
from dotenv import load_dotenv
from bible_parser import BibleParser

load_dotenv()
API_KEY = os.getenv("LLM_FOUNDRY_API_KEY")

def call_llm_foundry(user_text, rules_config):
    url = "https://llmfoundry.straive.com/gemini/v1beta/openai/chat/completions"
    headers = {
        "Authorization": f"Bearer {API_KEY}:my-test-project",
        "Content-Type": "application/json"
    }
    
    # SYSTEM PROMPT: Forces Gemini to return the specific JSON we need
    system_prompt = (
        "You are a scientific compliance editor. Return ONLY a JSON object. "
        "Do not include markdown code blocks or intro text. "
        "Format: {'corrected_text': '...', 'applied_rules': []}"
    )

    payload = {
        "model": "gemini-2.0-flash", # Matching your colleague's model
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": f"Rules: {json.dumps(rules_config)}\n\nText: {user_text}"}
        ],
        "temperature": 0.1
    }

    try:
        response = requests.post(url, headers=headers, json=payload, timeout=30)
        response.encoding = 'utf-8' # Force UTF-8 as per colleague's code
        
        if response.status_code != 200:
            print(f"Error: {response.status_code} - {response.text}")
            return {"error": "API Error", "corrected_text": "Server rejected request."}

        data = response.json()
        content = data['choices'][0]['message']['content']

        # --- COLLEAGUE'S DECODING FIXES ---
        try:
            # Clean up JSON formatting if AI adds it
            content = content.replace('```json', '').replace('```', '').strip()
            # Decode unicode escapes and repair Mojibake
            content = content.encode('utf-8').decode('unicode_escape')
            content = content.encode('latin1').decode('utf-8')
        except:
            pass

        # Manual Cleanup for leftovers
        cleanup = {"Â£": "£", "Â€": "€", "â‚¬": "€", "â‚¤": "£"}
        for bad, good in cleanup.items():
            content = content.replace(bad, good)

        # Convert the cleaned string back into a Python Dictionary
        return json.loads(content)

    except Exception as e:
        print(f"Python Error: {str(e)}")
        return {"error": str(e), "applied_rules": []}

# --- FLASK APP ---

app = Flask(__name__)
parser = BibleParser()
CONFIG_FILE = 'active_rules.json'

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload_bible_manual', methods=['POST'])
def upload_bible_manual():
    content = request.json.get('content', '')
    parser = BibleParser()
    config_data = parser.parse_text(content)
    
    with open('active_rules.json', 'w', encoding='utf-8') as f:
        json.dump(config_data, f, indent=2)
        
    return jsonify({
        "status": "success", 
        "rule_count": len(config_data['rules']),
        "preview": config_data
    })

@app.route('/upload_bible', methods=['POST'])
def upload_bible():
    if 'file' not in request.files:
        return jsonify({"error": "No file"}), 400
    
    file = request.files['file']
    content = file.read().decode('utf-8')
    
    parser = BibleParser()
    config_data = parser.parse_text(content)
    
    # Save the parsed JSON to a file for the AI to use
    with open('active_rules.json', 'w', encoding='utf-8') as f:
        json.dump(config_data, f, indent=2)
        
    return jsonify({
        "status": "success", 
        "rule_count": len(config_data['rules']),
        "preview": config_data  # This is what shows up in the UI sidebar
    })

@app.route('/process_text', methods=['POST'])
def process_text():
    # 1. Load the Active Rules
    if not os.path.exists(CONFIG_FILE):
        return jsonify({"error": "No Bible loaded! Upload a Bible first."}), 400
        
    with open(CONFIG_FILE, 'r') as f:
        rules_config = json.load(f)
        
    data = request.json
    user_text = data.get('text', '')
    
    # 2. THE DRIVER: Send Config + Text to LLM
    # This is where we hand off control to the AI
    llm_response = call_llm_foundry(user_text, rules_config)
    
    return jsonify(llm_response)

if __name__ == '__main__':
    app.run(debug=True)