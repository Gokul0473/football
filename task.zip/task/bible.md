# RULE START
rule_id: 1.1
category: Chemical Notation
triggers: H2O, CO2, H2SO4, NaCl
instruction: Use subscript characters for chemical formulas. Ensure numbers following element symbols are converted to their subscript equivalent.
exceptions: None
test_input: The CO2 and H2O levels in the lab.
test_output: The CO₂ and H₂O levels in the lab.
# RULE END

# RULE START
rule_id: 1.2
category: Plurals & Acronyms
triggers: 1960's, 1990's, GPS's, CEO's, acronyms
instruction: Add a lowercase 's' without an apostrophe for decades and plural acronyms. Use ’s ONLY for lowercase single letters.
exceptions: p’s and q’s
test_input: Many GPS's were produced in the 1990's.
test_output: Many GPSs were produced in the 1990s.
# RULE END

# RULE START
rule_id: 1.3
category: Units of Measure
triggers: degrees, celsius, fahrenheit
instruction: Use the degree symbol (°) immediately followed by the scale letter without a space.
exceptions: Kelvin (uses K only)
test_input: The sample was heated to 180 degrees Celsius.
test_output: The sample was heated to 180°C.
# RULE END

# RULE START
rule_id: 1.4
category: Currency
triggers: dollars, euros, pounds, GBP
instruction: Use the appropriate symbol ($, €, £) before the numerical value. Remove the word version of the currency.
exceptions: None
test_input: The cost was 500 dollars and 20 pounds.
test_output: The cost was $500 and £20.
# RULE END

# RULE START
rule_id: 1.5
category: Typography
triggers: ellipses, dots, ...
instruction: Replace three consecutive periods with the formal ellipsis character (…).
exceptions: None
test_input: To be continued...
test_output: To be continued…
# RULE END

# RULE START
rule_id: 2.1
category: Fractions
triggers: 1/2, 1/4, 3/4
instruction: Convert standard fractions to their single-character Unicode equivalents.
exceptions: Complex fractions like 5/16
test_input: Add 1/2 cup of water.
test_output: Add ½ cup of water.
# RULE END

# RULE START
rule_id: 2.2
category: Mathematics
triggers: +/- , plus minus
instruction: Use the unified plus-minus symbol (±).
exceptions: None
test_input: The variance is +/- 5 percent.
test_output: The variance is ± 5 percent.
# RULE END