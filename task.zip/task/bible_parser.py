import re
import json

class BibleParser:
    def parse_text(self, raw_text):
        """
        Converts raw Markdown into the exact JSON structure required.
        """
        # Split by the # RULE START delimiter
        blocks = re.split(r'#+\s*RULE START', raw_text, flags=re.IGNORECASE)
        rules = []

        for block in blocks:
            if not block.strip():
                continue
            
            # Extract fields using precise Regex
            rule_id = self._get_val(block, r"rule_id:\s*(.*)")
            if not rule_id:
                continue

            # Construct the exact dictionary structure
            rule_obj = {
                "rule_id": rule_id,
                "category": self._get_val(block, r"category:\s*(.*)"),
                "triggers": self._get_list(block, r"triggers:\s*(.*)"),
                "instruction": self._get_val(block, r"instruction:\s*(.*)"),
                "exceptions": self._get_list(block, r"exceptions:\s*(.*)"),
                "test_cases": self._get_test_cases(block)
            }
            rules.append(rule_obj)
            
        return {"rules": rules}

    def _get_val(self, block, pattern):
        match = re.search(pattern, block, re.IGNORECASE)
        return match.group(1).strip() if match else ""

    def _get_list(self, block, pattern):
        val = self._get_val(block, pattern)
        if not val or val.lower() == "none":
            return []
        # Split by comma and remove whitespace from each item
        return [item.strip() for item in val.split(',')]

    def _get_test_cases(self, block):
        inp = self._get_val(block, r"test_input:\s*(.*)")
        out = self._get_val(block, r"test_output:\s*(.*)")
        if inp:
            return [{"input": inp, "output": out}]
        return []

# Testing logic
if __name__ == "__main__":
    with open("bible.md", "r") as f:
        data = f.read()
    parser = BibleParser()
    print(json.dumps(parser.parse_text(data), indent=2))